package com.luxora.hisab

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// type: "IN" = আয়, "OUT" = ব্যয়
// channel: "GEN" সাধারণ, "WHOLE" পাইকারি, "RETAIL" খুচরা, "BUY" ক্রয়
@Entity(tableName = "txn")
data class Txn(
    @PrimaryKey val id: String,
    val date: Long,
    val personId: String,
    val personName: String,
    val details: String,
    val category: String,
    val type: String,
    val amount: Double,
    val paid: Double,
    val method: String,
    val notes: String,
    val channel: String,
    val updatedAt: Long,
    val deleted: Boolean = false,
    val deviceId: String = ""
)

// kind: "OWN" = নিজস্ব লোক, "EXT" = বাইরের লোক
@Entity(tableName = "person")
data class Person(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String,
    val kind: String,
    val updatedAt: Long,
    val deleted: Boolean = false
)

@Entity(tableName = "cat")
data class Cat(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val updatedAt: Long,
    val deleted: Boolean = false
)

@Dao
interface AppDao {
    @Query("SELECT * FROM txn") fun txns(): Flow<List<Txn>>
    @Query("SELECT * FROM person") fun people(): Flow<List<Person>>
    @Query("SELECT * FROM cat") fun cats(): Flow<List<Cat>>
    @Query("SELECT * FROM txn") suspend fun txnsOnce(): List<Txn>
    @Query("SELECT * FROM person") suspend fun peopleOnce(): List<Person>
    @Query("SELECT * FROM cat") suspend fun catsOnce(): List<Cat>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putTxns(l: List<Txn>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putPeople(l: List<Person>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putCats(l: List<Cat>)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun seedCats(l: List<Cat>)
}

@Database(entities = [Txn::class, Person::class, Cat::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "luxora.db")
                .build().also { inst = it }
        }
    }
}
