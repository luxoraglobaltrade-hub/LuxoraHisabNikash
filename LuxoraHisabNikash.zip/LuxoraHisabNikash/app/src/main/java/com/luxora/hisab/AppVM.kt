package com.luxora.hisab

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class AppVM(app: Application) : AndroidViewModel(app) {
    private val dao = Db.get(app).dao()
    private val prefs = app.getSharedPreferences("lx", 0)
    val deviceId: String = prefs.getString("dev", null)
        ?: UUID.randomUUID().toString().also { prefs.edit().putString("dev", it).apply() }

    val txns = dao.txns()
        .map { l -> l.filter { !it.deleted }.sortedWith(compareByDescending<Txn> { it.date }.thenByDescending { it.updatedAt }) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val people = dao.people()
        .map { l -> l.filter { !it.deleted }.sortedBy { it.name } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cats = dao.cats()
        .map { l -> l.filter { !it.deleted }.sortedBy { it.name } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            val inc = listOf("বিক্রয়", "পাইকারি বিক্রয়", "খুচরা বিক্রয়", "সেবা আয়", "অন্যান্য আয়")
            val exp = listOf("পণ্য ক্রয়", "বেতন", "দোকান ভাড়া", "বিদ্যুৎ বিল", "পরিবহন", "যাতায়াত", "খাবার", "অন্যান্য ব্যয়")
            val now = System.currentTimeMillis()
            // নির্দিষ্ট আইডি: একাধিক ফোনে ডিফল্ট ক্যাটাগরি ডুপ্লিকেট হবে না
            dao.seedCats(
                inc.mapIndexed { i, n -> Cat("def-IN-$i", n, "IN", now) } +
                    exp.mapIndexed { i, n -> Cat("def-OUT-$i", n, "OUT", now) }
            )
        }
    }

    private fun now() = System.currentTimeMillis()

    fun saveTxn(
        old: Txn?, date: Long, personName: String, details: String, category: String,
        type: String, amount: Double, paid: Double, method: String, notes: String, channel: String
    ) {
        viewModelScope.launch {
            val pn = personName.trim()
            var pid = ""
            if (pn.isNotEmpty()) {
                val ex = dao.peopleOnce().firstOrNull { !it.deleted && it.name.equals(pn, true) }
                if (ex != null) pid = ex.id else {
                    val p = Person(UUID.randomUUID().toString(), pn, "", "EXT", now())
                    dao.putPeople(listOf(p)); pid = p.id
                }
            }
            val cn = category.trim()
            if (cn.isNotEmpty() && dao.catsOnce().none { !it.deleted && it.name == cn && it.type == type }) {
                dao.putCats(listOf(Cat(UUID.randomUUID().toString(), cn, type, now())))
            }
            dao.putTxns(listOf(Txn(
                old?.id ?: UUID.randomUUID().toString(), date, pid, pn, details.trim(), cn, type,
                amount, paid, method, notes.trim(), channel, now(), false, deviceId
            )))
        }
    }

    fun deleteTxn(t: Txn) = viewModelScope.launch { dao.putTxns(listOf(t.copy(deleted = true, updatedAt = now()))) }

    fun addPayment(t: Txn, amt: Double) = viewModelScope.launch {
        dao.putTxns(listOf(t.copy(paid = minOf(t.amount, t.paid + amt), updatedAt = now(), deviceId = deviceId)))
    }

    fun savePerson(name: String, phone: String, kind: String) = viewModelScope.launch {
        if (dao.peopleOnce().none { !it.deleted && it.name.equals(name.trim(), true) })
            dao.putPeople(listOf(Person(UUID.randomUUID().toString(), name.trim(), phone.trim(), kind, now())))
    }

    fun deletePerson(p: Person) = viewModelScope.launch { dao.putPeople(listOf(p.copy(deleted = true, updatedAt = now()))) }

    fun saveCat(name: String, type: String) = viewModelScope.launch {
        if (dao.catsOnce().none { !it.deleted && it.name == name.trim() && it.type == type })
            dao.putCats(listOf(Cat(UUID.randomUUID().toString(), name.trim(), type, now())))
    }

    fun deleteCat(c: Cat) = viewModelScope.launch { dao.putCats(listOf(c.copy(deleted = true, updatedAt = now()))) }

    // ---------- ব্যাকআপ / সিঙ্ক ----------
    suspend fun exportJson(): String {
        val o = JSONObject()
        o.put("app", "luxora-hisab-nikash"); o.put("version", 1)
        o.put("exportedAt", now()); o.put("device", deviceId)
        val ta = JSONArray()
        dao.txnsOnce().forEach {
            ta.put(JSONObject().put("id", it.id).put("date", it.date).put("personId", it.personId)
                .put("personName", it.personName).put("details", it.details).put("category", it.category)
                .put("type", it.type).put("amount", it.amount).put("paid", it.paid).put("method", it.method)
                .put("notes", it.notes).put("channel", it.channel).put("updatedAt", it.updatedAt)
                .put("deleted", it.deleted).put("deviceId", it.deviceId))
        }
        val pa = JSONArray()
        dao.peopleOnce().forEach {
            pa.put(JSONObject().put("id", it.id).put("name", it.name).put("phone", it.phone)
                .put("kind", it.kind).put("updatedAt", it.updatedAt).put("deleted", it.deleted))
        }
        val ca = JSONArray()
        dao.catsOnce().forEach {
            ca.put(JSONObject().put("id", it.id).put("name", it.name).put("type", it.type)
                .put("updatedAt", it.updatedAt).put("deleted", it.deleted))
        }
        o.put("txns", ta); o.put("people", pa); o.put("cats", ca)
        return o.toString()
    }

    /** মার্জ: একই আইডি থাকলে নতুন (updatedAt বেশি) রেকর্ড জেতে; ডুপ্লিকেট হয় না। ফেরত: যোগ/আপডেট হওয়া রেকর্ড, ভুল ফাইল হলে -1 */
    suspend fun importJson(text: String): Int {
        val o = JSONObject(text)
        if (o.optString("app") != "luxora-hisab-nikash") return -1
        var n = 0
        val et = dao.txnsOnce().associate { it.id to it.updatedAt }
        val ta = o.optJSONArray("txns") ?: JSONArray()
        val tl = ArrayList<Txn>()
        for (i in 0 until ta.length()) {
            val j = ta.getJSONObject(i)
            val t = Txn(j.getString("id"), j.getLong("date"), j.optString("personId"), j.optString("personName"),
                j.optString("details"), j.optString("category"), j.getString("type"), j.getDouble("amount"),
                j.getDouble("paid"), j.optString("method"), j.optString("notes"), j.optString("channel", "GEN"),
                j.getLong("updatedAt"), j.optBoolean("deleted"), j.optString("deviceId"))
            val ex = et[t.id]
            if (ex == null || t.updatedAt > ex) tl.add(t)
        }
        dao.putTxns(tl); n += tl.size

        val ep = dao.peopleOnce().associate { it.id to it.updatedAt }
        val pa = o.optJSONArray("people") ?: JSONArray()
        val pl = ArrayList<Person>()
        for (i in 0 until pa.length()) {
            val j = pa.getJSONObject(i)
            val p = Person(j.getString("id"), j.getString("name"), j.optString("phone"), j.optString("kind", "EXT"),
                j.getLong("updatedAt"), j.optBoolean("deleted"))
            val ex = ep[p.id]
            if (ex == null || p.updatedAt > ex) pl.add(p)
        }
        dao.putPeople(pl); n += pl.size

        val ec = dao.catsOnce().associate { it.id to it.updatedAt }
        val ca = o.optJSONArray("cats") ?: JSONArray()
        val cl = ArrayList<Cat>()
        for (i in 0 until ca.length()) {
            val j = ca.getJSONObject(i)
            val c = Cat(j.getString("id"), j.getString("name"), j.getString("type"), j.getLong("updatedAt"), j.optBoolean("deleted"))
            val ex = ec[c.id]
            if (ex == null || c.updatedAt > ex) cl.add(c)
        }
        dao.putCats(cl); n += cl.size
        return n
    }
}
