package com.luxora.hisab

import java.util.*

val MONTHS = listOf(
    "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
    "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
)
val CHAN = linkedMapOf(
    "GEN" to "সাধারণ লেনদেন",
    "WHOLE" to "পাইকারি বিক্রয়",
    "RETAIL" to "খুচরা বিক্রয়",
    "BUY" to "পণ্য ক্রয়"
)
val METHODS = listOf("নগদ টাকা", "বিকাশ", "নগদ (মোবাইল ব্যাংকিং)", "রকেট", "ব্যাংক", "চেক", "বাকি")

fun bn(s: String): String = buildString {
    s.forEach { append(if (it in '0'..'9') '০' + (it - '0') else it) }
}

fun parseNum(s: String): Double? {
    val t = buildString {
        s.trim().forEach { ch ->
            when {
                ch in '০'..'৯' -> append('0' + (ch - '০'))
                ch != ',' -> append(ch)
            }
        }
    }
    return t.toDoubleOrNull()
}

fun taka(d: Double): String {
    val f = if (Math.abs(d % 1.0) < 0.005) String.format(Locale.US, "%,.0f", d)
    else String.format(Locale.US, "%,.2f", d)
    return "৳ " + bn(f)
}

fun plain(d: Double): String = if (d % 1.0 == 0.0) d.toLong().toString() else d.toString()

fun startOfDay(ms: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun dateStr(ms: Long): String {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    return bn("${c.get(Calendar.DAY_OF_MONTH)}") + " " + MONTHS[c.get(Calendar.MONTH)] + " " + bn("${c.get(Calendar.YEAR)}")
}

/** kind: 0 দৈনিক, 1 সাপ্তাহিক (শনিবার থেকে), 2 মাসিক, 3 বার্ষিক. off = আগে/পরে কত একক */
fun rangeOf(kind: Int, off: Int): Triple<Long, Long, String> {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    when (kind) {
        0 -> c.add(Calendar.DAY_OF_YEAR, off)
        1 -> {
            c.add(Calendar.WEEK_OF_YEAR, off)
            val diff = (c.get(Calendar.DAY_OF_WEEK) - Calendar.SATURDAY + 7) % 7
            c.add(Calendar.DAY_OF_YEAR, -diff)
        }
        2 -> { c.set(Calendar.DAY_OF_MONTH, 1); c.add(Calendar.MONTH, off) }
        else -> { c.set(Calendar.DAY_OF_YEAR, 1); c.add(Calendar.YEAR, off) }
    }
    val s = c.timeInMillis
    val e = Calendar.getInstance()
    e.timeInMillis = s
    when (kind) {
        0 -> e.add(Calendar.DAY_OF_YEAR, 1)
        1 -> e.add(Calendar.DAY_OF_YEAR, 7)
        2 -> e.add(Calendar.MONTH, 1)
        else -> e.add(Calendar.YEAR, 1)
    }
    val end = e.timeInMillis
    val label = when (kind) {
        0 -> dateStr(s)
        1 -> dateStr(s) + " – " + dateStr(end - 1)
        2 -> MONTHS[c.get(Calendar.MONTH)] + " " + bn("${c.get(Calendar.YEAR)}")
        else -> bn("${c.get(Calendar.YEAR)}") + " সাল"
    }
    return Triple(s, end, label)
}
