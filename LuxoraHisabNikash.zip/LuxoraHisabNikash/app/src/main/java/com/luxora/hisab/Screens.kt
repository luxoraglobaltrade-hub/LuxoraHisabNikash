@file:OptIn(ExperimentalMaterial3Api::class)

package com.luxora.hisab

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

val DG = Color(0xFF0B5D3B)
val G = Color(0xFF1B7F4F)
val LG = Color(0xFFE6F2EA)
val BG = Color(0xFFF4F8F5)
val Red = Color(0xFFC62828)

@Composable
fun LuxoraTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = lightColorScheme(
        primary = DG, onPrimary = Color.White, primaryContainer = LG, onPrimaryContainer = DG,
        secondary = G, background = BG, surface = Color.White, surfaceVariant = LG, error = Red
    ), content = content
)

// ============================ মূল কাঠামো ============================
@Composable
fun App(vm: AppVM) {
    val txns by vm.txns.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var sub by remember { mutableStateOf<String?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Txn?>(null) }
    var initCh by remember { mutableStateOf("GEN") }
    var initType by remember { mutableStateOf("IN") }

    BackHandler(enabled = showForm || sub != null || tab != 0) {
        when {
            showForm -> showForm = false
            sub != null -> sub = if (sub!!.startsWith("p:")) "people" else null
            else -> tab = 0
        }
    }

    fun openForm(t: Txn?, ch: String = "GEN", ty: String = "IN") {
        editing = t; initCh = ch; initType = ty; showForm = true
    }

    if (showForm) {
        TxnForm(vm, editing, initCh, initType) { showForm = false }
        return
    }

    val titles = listOf("ড্যাশবোর্ড", "লেনদেন", "বকেয়া হিসাব", "রিপোর্ট", "আরও")
    val subTitle = when {
        sub == "people" -> "ব্যক্তি ও হিসাব"
        sub?.startsWith("p:") == true -> "ব্যক্তির হিসাব"
        sub == "cats" -> "আয়-ব্যয়ের ক্যাটাগরি"
        sub == "backup" -> "ব্যাকআপ, রিস্টোর ও সিঙ্ক"
        else -> null
    }

    Scaffold(
        containerColor = BG,
        topBar = {
            TopAppBar(
                title = { Text(subTitle ?: ("লুক্সোরা হিসাব নিকাশ  •  " + titles[tab]), fontSize = 17.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (sub != null) IconButton(onClick = {
                        sub = if (sub!!.startsWith("p:")) "people" else null
                    }) { Icon(Icons.Default.ArrowBack, "পেছনে", tint = Color.White) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DG, titleContentColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                val items = listOf(
                    Icons.Default.Home to "ড্যাশবোর্ড", Icons.Default.ShoppingCart to "লেনদেন",
                    Icons.Default.Notifications to "বকেয়া", Icons.Default.Info to "রিপোর্ট",
                    Icons.Default.Menu to "আরও"
                )
                items.forEachIndexed { i, (ic, lb) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i; sub = null },
                        icon = { Icon(ic, lb) },
                        label = { Text(lb, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White, selectedTextColor = DG, indicatorColor = DG
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (sub == null && (tab == 0 || tab == 1))
                ExtendedFloatingActionButton(
                    onClick = { openForm(null) }, containerColor = DG, contentColor = Color.White
                ) { Text("＋ নতুন লেনদেন", fontWeight = FontWeight.Bold) }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                sub == "people" -> PeopleScreen(vm, txns) { sub = "p:$it" }
                sub?.startsWith("p:") == true -> StatementScreen(vm, txns, sub!!.removePrefix("p:"))
                sub == "cats" -> CatsScreen(vm)
                sub == "backup" -> BackupScreen(vm)
                tab == 0 -> Dashboard(txns, { ch, ty -> openForm(null, ch, ty) }, { openForm(it) })
                tab == 1 -> TxnList(vm, txns) { openForm(it) }
                tab == 2 -> Dues(vm, txns)
                tab == 3 -> Reports(txns)
                else -> MoreScreen { sub = it }
            }
        }
    }
}

// ============================ সাধারণ উপাদান ============================
@Composable
fun StatCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontSize = 13.sp, color = Color.Gray)
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun TxnCard(t: Txn, onClick: () -> Unit, onDelete: (() -> Unit)?) {
    val inc = t.type == "IN"
    val due = t.amount - t.paid
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.details.ifBlank { t.category.ifBlank { "লেনদেন" } }, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    (if (t.personName.isNotBlank()) t.personName + " • " else "") + t.category + " • " + dateStr(t.date),
                    fontSize = 12.sp, color = Color.Gray
                )
                Text(CHAN[t.channel] ?: "", fontSize = 11.sp, color = G)
                if (due > 0.004) Text((if (inc) "পাবো বাকি " else "দেবো বাকি ") + taka(due), fontSize = 12.sp, color = Red)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text((if (inc) "+ " else "− ") + taka(t.amount), color = if (inc) G else Red, fontWeight = FontWeight.Bold)
                if (onDelete != null) IconButton(onClick = onDelete, Modifier.size(30.dp)) {
                    Icon(Icons.Default.Delete, "মুছুন", tint = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun Combo(label: String, value: String, options: List<String>, editable: Boolean, onChange: (String) -> Unit) {
    var exp by remember { mutableStateOf(false) }
    val shown = if (editable) options.filter { it.contains(value, true) && !it.equals(value, true) } else options
    ExposedDropdownMenuBox(expanded = exp && shown.isNotEmpty(), onExpandedChange = { exp = it }) {
        OutlinedTextField(
            value = value,
            onValueChange = { if (editable) { onChange(it); exp = true } },
            readOnly = !editable, label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(exp) },
            modifier = Modifier.fillMaxWidth().menuAnchor(
                if (editable) MenuAnchorType.PrimaryEditable else MenuAnchorType.PrimaryNotEditable
            )
        )
        ExposedDropdownMenu(expanded = exp && shown.isNotEmpty(), onDismissRequest = { exp = false }) {
            shown.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onChange(o); exp = false }) }
        }
    }
}

@Composable
fun Stepper(label: String, text: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 12.sp, color = Color.Gray)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMinus) { Text("−", fontSize = 22.sp) }
            Text(text, fontWeight = FontWeight.Bold)
            IconButton(onClick = onPlus) { Text("+", fontSize = 22.sp) }
        }
    }
}

@Composable
fun DateField(ms: Long, onChange: (Long) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { show = true }, Modifier.fillMaxWidth()) { Text("তারিখ: " + dateStr(ms)) }
    if (show) {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        var d by remember { mutableIntStateOf(c.get(Calendar.DAY_OF_MONTH)) }
        var m by remember { mutableIntStateOf(c.get(Calendar.MONTH)) }
        var y by remember { mutableIntStateOf(c.get(Calendar.YEAR)) }
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text("তারিখ নির্বাচন") },
            text = {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stepper("দিন", bn("$d"), { d = if (d > 1) d - 1 else 31 }, { d = if (d < 31) d + 1 else 1 })
                    Stepper("মাস", MONTHS[m], { m = (m + 11) % 12 }, { m = (m + 1) % 12 })
                    Stepper("বছর", bn("$y"), { y -= 1 }, { y += 1 })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val cc = Calendar.getInstance(); cc.clear(); cc.set(y, m, 1)
                    val max = cc.getActualMaximum(Calendar.DAY_OF_MONTH)
                    cc.set(y, m, minOf(d, max))
                    onChange(startOfDay(cc.timeInMillis)); show = false
                }) { Text("ঠিক আছে") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { onChange(startOfDay(System.currentTimeMillis())); show = false }) { Text("আজ") }
                    TextButton(onClick = { show = false }) { Text("বাতিল") }
                }
            }
        )
    }
}

@Composable
fun DocActions(doc: ReportDoc, name: String) {
    val ctx = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                runCatching { shareFile(ctx, PdfMaker.create(ctx, doc, name), "application/pdf") }
                    .onFailure { toast(ctx, "PDF তৈরি করা যায়নি") }
            }, Modifier.weight(1f)) { Text("PDF") }
            OutlinedButton(onClick = {
                runCatching { printPdf(ctx, PdfMaker.create(ctx, doc, name), name) }
                    .onFailure { toast(ctx, "প্রিন্ট শুরু করা যায়নি") }
            }, Modifier.weight(1f)) { Text("প্রিন্ট") }
            OutlinedButton(onClick = {
                runCatching {
                    val f = File(File(ctx.cacheDir, "reports").apply { mkdirs() }, "$name.csv")
                    f.writeText(toCsv(doc)); shareFile(ctx, f, "text/csv")
                }.onFailure { toast(ctx, "এক্সপোর্ট করা যায়নি") }
            }, Modifier.weight(1f)) { Text("এক্সেল/CSV") }
        }
        Text("PDF বাটনে চাপ দিয়ে সংরক্ষণ বা শেয়ার করুন", fontSize = 11.sp, color = Color.Gray)
    }
}

// ============================ ১. ড্যাশবোর্ড ============================
@Composable
fun Dashboard(txns: List<Txn>, onNew: (String, String) -> Unit, onEdit: (Txn) -> Unit) {
    val today = startOfDay(System.currentTimeMillis())
    val ti = txns.filter { startOfDay(it.date) == today && it.type == "IN" }.sumOf { it.amount }
    val te = txns.filter { startOfDay(it.date) == today && it.type == "OUT" }.sumOf { it.amount }
    val bal = txns.filter { it.type == "IN" }.sumOf { it.paid } - txns.filter { it.type == "OUT" }.sumOf { it.paid }
    val rec = txns.filter { it.type == "IN" }.sumOf { it.amount - it.paid }
    val pay = txns.filter { it.type == "OUT" }.sumOf { it.amount - it.paid }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = DG)) {
                Column(Modifier.padding(20.dp)) {
                    Text("বর্তমান ব্যালেন্স", color = Color.White.copy(alpha = .8f))
                    Text(taka(bal), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("আজকের আয়", taka(ti), G, Modifier.weight(1f))
                StatCard("আজকের ব্যয়", taka(te), Red, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("মোট পাওনা", taka(rec), DG, Modifier.weight(1f))
                StatCard("মোট দেনা", taka(pay), Red, Modifier.weight(1f))
            }
        }
        item {
            Text("দ্রুত এন্ট্রি", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { onNew("WHOLE", "IN") }, Modifier.weight(1f)) { Text("পাইকারি\nবিক্রয়", fontSize = 12.sp) }
                FilledTonalButton(onClick = { onNew("RETAIL", "IN") }, Modifier.weight(1f)) { Text("খুচরা\nবিক্রয়", fontSize = 12.sp) }
                FilledTonalButton(onClick = { onNew("BUY", "OUT") }, Modifier.weight(1f)) { Text("পণ্য\nক্রয়", fontSize = 12.sp) }
                FilledTonalButton(onClick = { onNew("GEN", "OUT") }, Modifier.weight(1f)) { Text("খরচ", fontSize = 12.sp) }
            }
        }
        item { Text("সাম্প্রতিক লেনদেন", fontWeight = FontWeight.Bold) }
        if (txns.isEmpty()) item { Text("এখনো কোনো লেনদেন নেই। নিচের বাটনে চেপে প্রথম লেনদেন যোগ করুন।", color = Color.Gray) }
        items(txns.take(6), key = { it.id }) { TxnCard(it, { onEdit(it) }, null) }
    }
}

// ============================ ২. লেনদেন তালিকা ============================
@Composable
fun TxnList(vm: AppVM, txns: List<Txn>, onEdit: (Txn) -> Unit) {
    var f by remember { mutableStateOf("ALL") }
    var q by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<Txn?>(null) }
    val list = txns.filter { (f == "ALL" || it.channel == f) &&
        (q.isBlank() || (it.personName + it.details + it.category).contains(q, true)) }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(12.dp, 8.dp, 12.dp, 0.dp),
            label = { Text("খুঁজুন (নাম / বিবরণ / ক্যাটাগরি)") }, singleLine = true)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(f == "ALL", { f = "ALL" }, { Text("সব") })
            CHAN.forEach { (k, v) -> FilterChip(f == k, { f = k }, { Text(v) }) }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, 90.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (list.isEmpty()) item { Text("কোনো লেনদেন পাওয়া যায়নি", color = Color.Gray) }
            items(list, key = { it.id }) { TxnCard(it, { onEdit(it) }, { del = it }) }
        }
    }
    del?.let { t ->
        AlertDialog(
            onDismissRequest = { del = null }, title = { Text("লেনদেন মুছবেন?") },
            text = { Text("${t.details.ifBlank { t.category }} – ${taka(t.amount)}") },
            confirmButton = { TextButton(onClick = { vm.deleteTxn(t); del = null }) { Text("মুছুন", color = Red) } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("না") } }
        )
    }
}

// ============================ ৩. নতুন লেনদেন ফর্ম ============================
@Composable
fun TxnForm(vm: AppVM, old: Txn?, initCh: String, initType: String, onClose: () -> Unit) {
    val people by vm.people.collectAsState()
    val cats by vm.cats.collectAsState()
    var date by remember { mutableLongStateOf(old?.date ?: startOfDay(System.currentTimeMillis())) }
    var type by remember { mutableStateOf(old?.type ?: initType) }
    var channel by remember { mutableStateOf(old?.channel ?: initCh) }
    var person by remember { mutableStateOf(old?.personName ?: "") }
    var details by remember { mutableStateOf(old?.details ?: "") }
    var category by remember { mutableStateOf(old?.category ?: "") }
    var amount by remember { mutableStateOf(old?.amount?.let { plain(it) } ?: "") }
    var paid by remember { mutableStateOf(if (old != null && old.paid != old.amount) plain(old.paid) else "") }
    var method by remember { mutableStateOf(old?.method ?: METHODS[0]) }
    var notes by remember { mutableStateOf(old?.notes ?: "") }
    var err by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    BackHandler { onClose() }
    Scaffold(
        containerColor = BG,
        topBar = {
            TopAppBar(
                title = { Text(if (old == null) "নতুন লেনদেন" else "লেনদেন সম্পাদনা", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "পেছনে", tint = Color.White) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DG, titleContentColor = Color.White)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            DateField(date) { date = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(type == "IN", { type = "IN"; category = "" }, { Text("আয় (টাকা পাওয়া)") })
                FilterChip(type == "OUT", { type = "OUT"; category = "" }, { Text("ব্যয় (টাকা দেওয়া)") })
            }
            Combo("লেনদেনের ধরন (পাইকারি / খুচরা / ক্রয়)", CHAN[channel] ?: "", CHAN.values.toList(), false) { sel ->
                channel = CHAN.entries.first { it.value == sel }.key
                if (channel == "WHOLE" || channel == "RETAIL") { type = "IN"; category = sel }
                if (channel == "BUY") { type = "OUT"; category = "পণ্য ক্রয়" }
            }
            Combo("ব্যক্তির নাম", person, people.map { it.name }, true) { person = it }
            OutlinedTextField(details, { details = it }, Modifier.fillMaxWidth(), label = { Text("লেনদেনের বিবরণ") })
            Combo("ক্যাটাগরি (নতুন লিখলে নিজে যোগ হবে)", category,
                cats.filter { it.type == type }.map { it.name }, true) { category = it }
            OutlinedTextField(amount, { amount = it }, Modifier.fillMaxWidth(), label = { Text("মোট টাকার পরিমাণ (৳)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(paid, { paid = it }, Modifier.fillMaxWidth(),
                label = { Text(if (type == "IN") "নগদ পাওয়া গেছে (ফাঁকা = পুরোটা)" else "নগদ দেওয়া হয়েছে (ফাঁকা = পুরোটা)") },
                supportingText = { Text("কম লিখলে বাকিটা বকেয়া হিসাবে যাবে") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            Combo("পেমেন্ট পদ্ধতি", method, METHODS, false) { method = it }
            OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth(), label = { Text("নোট") }, minLines = 2)
            if (err.isNotEmpty()) Text(err, color = Red)
            Button(
                enabled = !saved,
                onClick = {
                    val a = parseNum(amount)
                    val p = if (paid.isBlank()) a else parseNum(paid)
                    when {
                        a == null || a <= 0 -> err = "সঠিক টাকার পরিমাণ লিখুন"
                        p == null || p < 0 -> err = "নগদ টাকার পরিমাণ সঠিক নয়"
                        p > a -> err = "নগদ টাকা মোট টাকার চেয়ে বেশি হতে পারে না"
                        p < a && person.isBlank() -> err = "বাকি থাকলে ব্যক্তির নাম দিতে হবে"
                        category.isBlank() -> err = "ক্যাটাগরি দিন"
                        else -> {
                            saved = true // একই লেনদেন দুইবার সেভ হওয়া আটকায়
                            vm.saveTxn(old, date, person, details, category, type, a, p, method, notes, channel)
                            onClose()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("সংরক্ষণ করুন", fontSize = 16.sp) }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ============================ ৬. বকেয়া হিসাব ============================
@Composable
fun Dues(vm: AppVM, txns: List<Txn>) {
    var mode by remember { mutableIntStateOf(0) }
    var payFor by remember { mutableStateOf<Txn?>(null) }
    val rec = txns.filter { it.type == "IN" && it.amount - it.paid > 0.004 }
    val pay = txns.filter { it.type == "OUT" && it.amount - it.paid > 0.004 }
    val settled = txns.filter { it.personName.isNotBlank() && it.amount - it.paid <= 0.004 }
    val list = when (mode) { 0 -> rec; 1 -> pay; else -> settled }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("আমরা পাবো", taka(rec.sumOf { it.amount - it.paid }), G, Modifier.weight(1f))
                StatCard("আমরা দেবো", taka(pay.sumOf { it.amount - it.paid }), Red, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(mode == 0, { mode = 0 }, { Text("কার কাছে পাবো") })
                FilterChip(mode == 1, { mode = 1 }, { Text("কাকে দেবো") })
                FilterChip(mode == 2, { mode = 2 }, { Text("পরিশোধিত") })
            }
        }
        if (list.isEmpty()) item { Text(if (mode == 2) "পরিশোধিত কোনো এন্ট্রি নেই" else "কোনো বকেয়া নেই 🎉", color = Color.Gray) }
        list.groupBy { it.personName.ifBlank { "নামহীন" } }.forEach { (name, l) ->
            item(key = "h$name$mode") {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(name, fontWeight = FontWeight.Bold, color = DG)
                    Text(if (mode == 2) taka(l.sumOf { it.amount }) else "বাকি " + taka(l.sumOf { it.amount - it.paid }),
                        fontWeight = FontWeight.Bold, color = if (mode == 1) Red else G)
                }
            }
            items(l, key = { it.id + mode }) { t ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(t.details.ifBlank { t.category } + " • " + dateStr(t.date), fontWeight = FontWeight.SemiBold)
                        Text("মোট ${taka(t.amount)}   পরিশোধিত ${taka(t.paid)}   বাকি ${taka(t.amount - t.paid)}", fontSize = 12.sp, color = Color.Gray)
                        if (mode != 2) Button(onClick = { payFor = t }, Modifier.padding(top = 6.dp)) {
                            Text(if (t.type == "IN") "টাকা গ্রহণ করুন" else "টাকা পরিশোধ করুন")
                        }
                    }
                }
            }
        }
    }
    payFor?.let { t ->
        var amt by remember(t.id) { mutableStateOf(plain(t.amount - t.paid)) }
        AlertDialog(
            onDismissRequest = { payFor = null },
            title = { Text(if (t.type == "IN") "টাকা গ্রহণ" else "টাকা পরিশোধ") },
            text = {
                OutlinedTextField(amt, { amt = it }, label = { Text("টাকার পরিমাণ (৳)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            },
            confirmButton = {
                TextButton(onClick = { parseNum(amt)?.takeIf { it > 0 }?.let { vm.addPayment(t, it) }; payFor = null }) { Text("সংরক্ষণ") }
            },
            dismissButton = { TextButton(onClick = { payFor = null }) { Text("বাতিল") } }
        )
    }
}

// ============================ ৭. রিপোর্ট ============================
@Composable
fun Reports(txns: List<Txn>) {
    var kind by remember { mutableIntStateOf(2) }
    var off by remember { mutableIntStateOf(0) }
    val r = remember(kind, off) { rangeOf(kind, off) }
    val list = txns.filter { it.date >= r.first && it.date < r.second }
    val doc = buildDoc("লুক্সোরা হিসাব নিকাশ – রিপোর্ট", r.third, list)
    val inc = list.filter { it.type == "IN" }.sumOf { it.amount }
    val exp = list.filter { it.type == "OUT" }.sumOf { it.amount }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("দৈনিক", "সাপ্তাহিক", "মাসিক", "বার্ষিক").forEachIndexed { i, s ->
                    FilterChip(kind == i, { kind = i; off = 0 }, { Text(s) })
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { off-- }) { Text("◀ আগে") }
                Text(r.third, fontWeight = FontWeight.Bold, color = DG)
                TextButton(onClick = { off++ }, enabled = off < 0) { Text("পরে ▶") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("মোট আয়", taka(inc), G, Modifier.weight(1f))
                StatCard("মোট ব্যয়", taka(exp), Red, Modifier.weight(1f))
            }
        }
        item {
            StatCard(if (inc - exp >= 0) "নীট লাভ" else "নীট ক্ষতি", taka(Math.abs(inc - exp)),
                if (inc - exp >= 0) G else Red, Modifier.fillMaxWidth())
        }
        item { DocActions(doc, "report_${kind}_${r.first}") }
        item { Text("ক্যাটাগরি অনুযায়ী", fontWeight = FontWeight.Bold) }
        items(doc.summary.drop(6)) { (k, v) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(k); Text(v, fontWeight = FontWeight.SemiBold) }
        }
        item { Text("লেনদেনের তালিকা (${bn("${list.size}")}টি)", fontWeight = FontWeight.Bold) }
        items(list, key = { it.id }) { TxnCard(it, {}, null) }
    }
}

// ============================ ৪. ব্যক্তি ও আলাদা হিসাব ============================
fun personBal(txns: List<Txn>, pid: String): Double =
    txns.filter { it.personId == pid }.sumOf { if (it.type == "IN") it.amount - it.paid else -(it.amount - it.paid) }

@Composable
fun PeopleScreen(vm: AppVM, txns: List<Txn>, onOpen: (String) -> Unit) {
    val people by vm.people.collectAsState()
    var kind by remember { mutableStateOf("OWN") }
    var add by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf<Person?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(kind == "OWN", { kind = "OWN" }, { Text("নিজস্ব লোক") })
                FilterChip(kind == "EXT", { kind = "EXT" }, { Text("বাইরের লোক") })
            }
        }
        item { Button(onClick = { add = true }, Modifier.fillMaxWidth()) { Text("＋ নতুন ব্যক্তি যোগ করুন") } }
        val l = people.filter { it.kind == kind }
        if (l.isEmpty()) item { Text("কেউ নেই", color = Color.Gray) }
        items(l, key = { it.id }) { p ->
            val b = personBal(txns, p.id)
            Card(Modifier.fillMaxWidth().clickable { onOpen(p.id) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        if (p.phone.isNotBlank()) Text(bn(p.phone), fontSize = 12.sp, color = Color.Gray)
                        Text(
                            when { b > 0.004 -> "পাবো " + taka(b); b < -0.004 -> "দেবো " + taka(-b); else -> "কোনো বকেয়া নেই" },
                            fontSize = 13.sp, color = if (b < -0.004) Red else G
                        )
                    }
                    IconButton(onClick = { del = p }) { Icon(Icons.Default.Delete, "মুছুন", tint = Color.Gray) }
                }
            }
        }
    }
    if (add) {
        var n by remember { mutableStateOf("") }
        var ph by remember { mutableStateOf("") }
        var k by remember { mutableStateOf(kind) }
        AlertDialog(
            onDismissRequest = { add = false }, title = { Text("নতুন ব্যক্তি") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(n, { n = it }, label = { Text("নাম") }, singleLine = true)
                    OutlinedTextField(ph, { ph = it }, label = { Text("ফোন (ঐচ্ছিক)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(k == "OWN", { k = "OWN" }, { Text("নিজস্ব") })
                        FilterChip(k == "EXT", { k = "EXT" }, { Text("বাইরের") })
                    }
                }
            },
            confirmButton = { TextButton(onClick = { if (n.isNotBlank()) vm.savePerson(n, ph, k); add = false }) { Text("সংরক্ষণ") } },
            dismissButton = { TextButton(onClick = { add = false }) { Text("বাতিল") } }
        )
    }
    del?.let { p ->
        AlertDialog(
            onDismissRequest = { del = null }, title = { Text("${p.name} কে মুছবেন?") },
            text = { Text("পুরোনো লেনদেন থাকবে, শুধু তালিকা থেকে নাম সরে যাবে।") },
            confirmButton = { TextButton(onClick = { vm.deletePerson(p); del = null }) { Text("মুছুন", color = Red) } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("না") } }
        )
    }
}

@Composable
fun StatementScreen(vm: AppVM, txns: List<Txn>, pid: String) {
    val people by vm.people.collectAsState()
    val p = people.firstOrNull { it.id == pid }
    val list = txns.filter { it.personId == pid }
    val doc = buildDoc("হিসাব বিবরণী – ${p?.name ?: ""}", (if (p?.kind == "OWN") "নিজস্ব লোক" else "বাইরের লোক") + " • " + dateStr(System.currentTimeMillis()), list)
    val b = personBal(txns, pid)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text(p?.name ?: "", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = DG) }
        item {
            StatCard(when { b > 0.004 -> "আমরা পাবো"; b < -0.004 -> "আমরা দেবো"; else -> "বকেয়া" },
                taka(Math.abs(b)), if (b < -0.004) Red else G, Modifier.fillMaxWidth())
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("মোট আয়/বিক্রয়", taka(list.filter { it.type == "IN" }.sumOf { it.amount }), G, Modifier.weight(1f))
                StatCard("মোট ব্যয়/ক্রয়", taka(list.filter { it.type == "OUT" }.sumOf { it.amount }), Red, Modifier.weight(1f))
            }
        }
        item { DocActions(doc, "statement_${p?.id ?: "x"}") }
        items(list, key = { it.id }) { TxnCard(it, {}, null) }
    }
}

// ============================ ৫. ক্যাটাগরি ============================
@Composable
fun CatsScreen(vm: AppVM) {
    val cats by vm.cats.collectAsState()
    var type by remember { mutableStateOf("IN") }
    var name by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(type == "IN", { type = "IN" }, { Text("আয়ের ক্যাটাগরি") })
                FilterChip(type == "OUT", { type = "OUT" }, { Text("ব্যয়ের ক্যাটাগরি") })
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, Modifier.weight(1f), label = { Text("নতুন ক্যাটাগরির নাম") }, singleLine = true)
                Button(onClick = { if (name.isNotBlank()) { vm.saveCat(name, type); name = "" } }) { Text("যোগ") }
            }
        }
        items(cats.filter { it.type == type }, key = { it.id }) { c ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(c.name, Modifier.weight(1f))
                    IconButton(onClick = { vm.deleteCat(c) }) { Icon(Icons.Default.Delete, "মুছুন", tint = Color.Gray) }
                }
            }
        }
    }
}

// ============================ ৯,১০. ব্যাকআপ / সিঙ্ক ============================
@Composable
fun BackupScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmImport by remember { mutableStateOf<android.net.Uri?>(null) }

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val s = vm.exportJson()
                withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri)?.use { it.write(s.toByteArray()) } }
            }.onSuccess { toast(ctx, "ব্যাকআপ সংরক্ষিত হয়েছে") }.onFailure { toast(ctx, "ব্যাকআপ ব্যর্থ হয়েছে") }
        }
    }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) confirmImport = uri }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("সব লেনদেন ফোনের ভেতরেই সংরক্ষিত থাকে (ইন্টারনেট লাগে না)। অ্যাপ বন্ধ করলেও ডেটা হারায় না।", color = Color.DarkGray)
        Text("ব্যাকআপ ও রিস্টোর", fontWeight = FontWeight.Bold, color = DG)
        Button(onClick = { save.launch("luxora_backup_${System.currentTimeMillis()}.json") }, Modifier.fillMaxWidth()) { Text("ব্যাকআপ ফাইল সংরক্ষণ করুন") }
        OutlinedButton(onClick = { open.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("ব্যাকআপ থেকে রিস্টোর করুন") }
        HorizontalDivider()
        Text("একাধিক ফোনে সিঙ্ক", fontWeight = FontWeight.Bold, color = DG)
        Text("প্রতিটি লেনদেনের একটি অনন্য আইডি আছে, তাই একই ফাইল বারবার মেলালেও ডুপ্লিকেট হয় না। একই লেনদেন দুই ফোনে বদলালে নতুন সময়ের পরিবর্তনটি থাকে।", fontSize = 13.sp, color = Color.DarkGray)
        Button(onClick = {
            scope.launch {
                runCatching {
                    val s = vm.exportJson()
                    val f = File(File(ctx.cacheDir, "reports").apply { mkdirs() }, "luxora_sync.json")
                    withContext(Dispatchers.IO) { f.writeText(s) }
                    shareFile(ctx, f, "application/json")
                }.onFailure { toast(ctx, "সিঙ্ক ফাইল তৈরি করা যায়নি") }
            }
        }, Modifier.fillMaxWidth()) { Text("সিঙ্ক ফাইল পাঠান (WhatsApp/ব্লুটুথ/নিয়ারবাই)") }
        OutlinedButton(onClick = { open.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("অন্য ফোনের সিঙ্ক ফাইল মেলান") }
        HorizontalDivider()
        Text("অ্যাপ শেয়ার (প্লে স্টোর ছাড়া)", fontWeight = FontWeight.Bold, color = DG)
        Button(onClick = {
            runCatching {
                val src = File(ctx.applicationInfo.sourceDir)
                val f = File(File(ctx.cacheDir, "reports").apply { mkdirs() }, "LuxoraHisabNikash.apk")
                src.copyTo(f, overwrite = true)
                shareFile(ctx, f, "application/vnd.android.package-archive")
            }.onFailure { toast(ctx, "APK শেয়ার করা যায়নি") }
        }, Modifier.fillMaxWidth()) { Text("এই অ্যাপের APK শেয়ার করুন") }
    }
    confirmImport?.let { uri ->
        AlertDialog(
            onDismissRequest = { confirmImport = null },
            title = { Text("ফাইলের ডেটা মেলাবেন?") },
            text = { Text("নতুন রেকর্ড যোগ হবে, আগেরগুলো ডুপ্লিকেট হবে না। আপনার বর্তমান ডেটা মুছবে না।") },
            confirmButton = {
                TextButton(onClick = {
                    confirmImport = null
                    scope.launch {
                        runCatching {
                            val text = withContext(Dispatchers.IO) { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: "" }
                            vm.importJson(text)
                        }.onSuccess { n ->
                            toast(ctx, if (n < 0) "এটি Luxora ব্যাকআপ ফাইল নয়" else "সফল! ${bn("$n")}টি রেকর্ড যোগ/আপডেট হয়েছে")
                        }.onFailure { toast(ctx, "ফাইলটি পড়া যায়নি") }
                    }
                }) { Text("মেলান") }
            },
            dismissButton = { TextButton(onClick = { confirmImport = null }) { Text("বাতিল") } }
        )
    }
}

// ============================ আরও ============================
@Composable
fun MoreScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf(
            "people" to "ব্যক্তি ও আলাদা হিসাব (নিজস্ব / বাইরের লোক)",
            "cats" to "আয়-ব্যয়ের ক্যাটাগরি (কাস্টম সহ)",
            "backup" to "ব্যাকআপ, রিস্টোর, সিঙ্ক ও APK শেয়ার"
        ).forEach { (k, v) ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(k) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Text(v, Modifier.padding(18.dp), fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.weight(1f))
        Text("লুক্সোরা হিসাব নিকাশ • সংস্করণ ১.০", color = Color.Gray, fontSize = 12.sp)
    }
}
