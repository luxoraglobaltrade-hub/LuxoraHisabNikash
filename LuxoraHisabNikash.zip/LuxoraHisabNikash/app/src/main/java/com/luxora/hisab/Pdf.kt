package com.luxora.hisab

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

data class ReportDoc(
    val title: String,
    val subtitle: String,
    val summary: List<Pair<String, String>>,
    val rows: List<List<String>>
)

val HEAD = listOf("তারিখ", "নাম", "বিবরণ", "ক্যাটাগরি", "ধরন", "মোট", "পরিশোধ")
val WTS = floatArrayOf(1.5f, 1.5f, 2.2f, 1.5f, 0.8f, 1.3f, 1.3f)

fun buildDoc(title: String, subtitle: String, l: List<Txn>): ReportDoc {
    val inc = l.filter { it.type == "IN" }.sumOf { it.amount }
    val exp = l.filter { it.type == "OUT" }.sumOf { it.amount }
    val rec = l.filter { it.type == "IN" }.sumOf { it.amount - it.paid }
    val pay = l.filter { it.type == "OUT" }.sumOf { it.amount - it.paid }
    val s = mutableListOf(
        "মোট আয়" to taka(inc), "মোট ব্যয়" to taka(exp),
        (if (inc - exp >= 0) "নীট লাভ" else "নীট ক্ষতি") to taka(Math.abs(inc - exp)),
        "পাওনা বাকি" to taka(rec), "দেনা বাকি" to taka(pay),
        "লেনদেন সংখ্যা" to bn("${l.size}")
    )
    l.groupBy { it.type + "|" + it.category }.toSortedMap().forEach { (k, v) ->
        val (ty, cat) = k.split("|", limit = 2)
        s.add(((if (ty == "IN") "আয় – " else "ব্যয় – ") + cat.ifBlank { "অন্যান্য" }) to taka(v.sumOf { it.amount }))
    }
    val rows = l.sortedBy { it.date }.map {
        listOf(dateStr(it.date), it.personName.ifBlank { "-" }, it.details.ifBlank { "-" },
            it.category.ifBlank { "-" }, if (it.type == "IN") "আয়" else "ব্যয়", taka(it.amount), taka(it.paid))
    }
    return ReportDoc(title, subtitle, s, rows)
}

fun toCsv(d: ReportDoc): String {
    fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    val sb = StringBuilder("\uFEFF")
    sb.append(HEAD.joinToString(",") { q(it) }).append("\n")
    d.rows.forEach { r -> sb.append(r.joinToString(",") { q(it) }).append("\n") }
    return sb.toString()
}

object PdfMaker {
    private const val W = 595
    private const val H = 842
    private const val M = 32f

    private fun lay(text: String, p: TextPaint, w: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, w)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

    fun create(ctx: Context, doc: ReportDoc, name: String): File {
        val dir = File(ctx.cacheDir, "reports").apply { mkdirs() }
        val file = File(dir, name.replace(Regex("[^A-Za-z0-9_\\-]"), "_") + ".pdf")
        val pdf = PdfDocument()
        val green = Color.parseColor("#0B5D3B")
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; color = Color.BLACK }
        val bold = TextPaint(tp).apply { typeface = Typeface.DEFAULT_BOLD }
        val white = TextPaint(bold).apply { color = Color.WHITE }
        var pageNo = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
        var cv = page.canvas
        var y = M

        fun footer() {
            val p = TextPaint(tp).apply { textSize = 8f; color = Color.GRAY }
            cv.drawText("লুক্সোরা হিসাব নিকাশ  •  পৃষ্ঠা " + bn("$pageNo"), M, H - 16f, p)
        }
        fun newPage() {
            footer(); pdf.finishPage(page); pageNo++
            page = pdf.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            cv = page.canvas; y = M
        }

        val tw = W - 2 * M
        val sum = WTS.sum()
        val widths = WTS.map { it * tw / sum }

        fun drawHeader() {
            val ls = HEAD.mapIndexed { i, h -> lay(h, white, (widths[i] - 8).toInt()) }
            val h = (ls.maxOf { it.height } + 8).toFloat()
            val bg = Paint().apply { color = green }
            cv.drawRect(M, y, M + tw, y + h, bg)
            var x = M
            ls.forEachIndexed { i, l ->
                cv.save(); cv.translate(x + 4, y + 4); l.draw(cv); cv.restore(); x += widths[i]
            }
            y += h
        }

        // শিরোনাম
        cv.drawRect(M, y, M + tw, y + 52, Paint().apply { color = green })
        val tt = TextPaint(white).apply { textSize = 17f }
        cv.save(); cv.translate(M + 10, y + 8); lay(doc.title, tt, (tw - 20).toInt()).draw(cv); cv.restore()
        val st = TextPaint(tp).apply { textSize = 10f; color = Color.WHITE }
        cv.save(); cv.translate(M + 10, y + 32); lay(doc.subtitle, st, (tw - 20).toInt()).draw(cv); cv.restore()
        y += 66

        // সারসংক্ষেপ
        doc.summary.forEach { (k, v) ->
            if (y > H - 60) newPage()
            cv.drawText(k, M + 4, y + 10, tp)
            val r = TextPaint(bold).apply { textAlign = Paint.Align.RIGHT }
            cv.drawText(v, M + 260, y + 10, r)
            y += 15
        }
        y += 12
        drawHeader()

        val light = Paint().apply { color = Color.parseColor("#EEF6F0") }
        val line = Paint().apply { color = Color.parseColor("#C8D8CD"); strokeWidth = 0.5f }
        doc.rows.forEachIndexed { ri, r ->
            val ls = r.mapIndexed { i, c -> lay(c, tp, (widths[i] - 8).toInt()) }
            val h = (ls.maxOf { it.height } + 6).toFloat()
            if (y + h > H - 40) { newPage(); drawHeader() }
            if (ri % 2 == 0) cv.drawRect(M, y, M + tw, y + h, light)
            var x = M
            ls.forEachIndexed { i, l ->
                cv.save(); cv.translate(x + 4, y + 3); l.draw(cv); cv.restore(); x += widths[i]
            }
            cv.drawLine(M, y + h, M + tw, y + h, line)
            y += h
        }
        if (doc.rows.isEmpty()) cv.drawText("এই সময়ে কোনো লেনদেন নেই", M + 4, y + 16, tp)

        footer(); pdf.finishPage(page)
        FileOutputStream(file).use { pdf.writeTo(it) }
        pdf.close()
        return file
    }
}

fun findActivity(c: Context): Activity? {
    var x: Context? = c
    while (x is ContextWrapper) { if (x is Activity) return x; x = x.baseContext }
    return null
}

fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_LONG).show()

fun shareFile(ctx: Context, f: File, mime: String) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "শেয়ার / সংরক্ষণ করুন").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun printPdf(ctx: Context, f: File, jobName: String) {
    val act = findActivity(ctx) ?: return
    val pm = act.getSystemService(Context.PRINT_SERVICE) as PrintManager
    pm.print(jobName, object : PrintDocumentAdapter() {
        override fun onLayout(
            o: PrintAttributes?, n: PrintAttributes?, c: CancellationSignal?,
            cb: LayoutResultCallback, e: Bundle?
        ) {
            if (c?.isCanceled == true) { cb.onLayoutCancelled(); return }
            cb.onLayoutFinished(
                PrintDocumentInfo.Builder(f.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true
            )
        }
        override fun onWrite(
            p: Array<out PageRange>?, d: ParcelFileDescriptor, c: CancellationSignal?, cb: WriteResultCallback
        ) {
            try {
                FileInputStream(f).use { i -> FileOutputStream(d.fileDescriptor).use { o -> i.copyTo(o) } }
                cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (ex: Exception) { cb.onWriteFailed(ex.message) }
        }
    }, null)
}
